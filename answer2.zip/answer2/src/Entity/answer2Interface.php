<?php

namespace Drupal\answer2\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Answer2 entities.
 */
interface answer2Interface extends ConfigEntityInterface {

  // Add get/set methods for your configuration properties here.
}
