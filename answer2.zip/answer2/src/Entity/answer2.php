<?php

namespace Drupal\answer2\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;

/**
 * Defines the Answer2 entity.
 *
 * @ConfigEntityType(
 *   id = "answer2",
 *   label = @Translation("Answer2"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\answer2\answer2ListBuilder",
 *     "form" = {
 *       "add" = "Drupal\answer2\Form\answer2Form",
 *       "edit" = "Drupal\answer2\Form\answer2Form",
 *       "delete" = "Drupal\answer2\Form\answer2DeleteForm"
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\answer2\answer2HtmlRouteProvider",
 *     },
 *   },
 *   config_prefix = "answer2",
 *   admin_permission = "administer site configuration",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/answer2/{answer2}",
 *     "add-form" = "/admin/structure/answer2/add",
 *     "edit-form" = "/admin/structure/answer2/{answer2}/edit",
 *     "delete-form" = "/admin/structure/answer2/{answer2}/delete",
 *     "collection" = "/admin/structure/answer2"
 *   }
 * )
 */
class answer2 extends ConfigEntityBase implements answer2Interface {

  /**
   * The Answer2 ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The Answer2 label.
   *
   * @var string
   */
  protected $label;

}
