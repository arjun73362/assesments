<?php

namespace Drupal\answer2\Form;

use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class answer2Form.
 */
class answer2Form extends EntityForm {

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);

    $answer2 = $this->entity;
    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Customer'),
      '#maxlength' => 255,
      '#default_value' => $answer2->label(),
      '#description' => $this->t("Label for the Answer2."),
      '#required' => TRUE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $answer2->id(),
      '#machine_name' => [
        'exists' => '\Drupal\answer2\Entity\answer2::load',
      ],
      '#disabled' => !$answer2->isNew(),
    ];

    $form['timeslot'] = [
      '#type' => 'select',
      '#options'=>[1=>'Time slot -1 (9:00 Am - 11:00 Am)' ,2=>'Time slot - 2( 11:00 Am - 2:00 pm)',3=>'Time slot -3 (2:00 pm - 5:00 pm)' ],
      '#title' => 'Timeslot',
      // '#default_value' => $detailcustomer->timeslot(),
      // '#machine_name' => [
      // 'exists' => '\Drupal\seecont\Entity\detailcustomer::load',
      // ],
      // '#disabled' => !$detailcustomer->isNew(),
      ];

    /* You will need additional form elements for your custom properties. */

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $answer2 = $this->entity;
    $status = $answer2->save();

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addMessage($this->t('Created the %label Answer2.', [
          '%label' => $answer2->label(),
        ]));
        break;

      default:
        $this->messenger()->addMessage($this->t('Saved the %label Answer2.', [
          '%label' => $answer2->label(),
        ]));
    }
    $form_state->setRedirectUrl($answer2->toUrl('collection'));
  }

}
