<?php

namespace Drupal\answer1\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Answer1 entities.
 *
 * @ingroup answer1
 */
class answer1DeleteForm extends ContentEntityDeleteForm {


}
