<?php
namespace Drupal\custom_services;
use Drupal\Core\Controller\ControllerBase;
use Drupal\custom_services;
class cmod1Controller extends ControllerBase{
  public function listing() {
  //  return array('#markup'=>$this->t('hello'));
  $hello = \Drupal::service('custom_services.hello');
  //kint($hello -> whoIsYourOwner());
  return array('#markup'=>$this->t($hello -> whoIsYourOwner()));
  }
}