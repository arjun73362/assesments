<?php
/**
 * @file
 * contains \Drupal\custom_services\Plugin\Block\CustomBlock
 */
namespace Drupal\custom_services\Plugin\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\custom_services;
/**
 * provides custom_contact_block List Block
 * @Block(
 *   id="custom_contact_block_service",
 *   admin_label=@Translation("custom_contact_data_service Block"),
 * )
 */
class CustomBlock extends BlockBase{
    /**
     * {@inheritdoc}
     */
    public function build(){
        $hello = \Drupal::service('custom_services.hello');
        //kint($hello -> whoIsYourOwner());
        return array('#markup'=>$this->t($hello -> whoIsYourOwner()));
    }
}