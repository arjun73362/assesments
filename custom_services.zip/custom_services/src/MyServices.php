<?php

namespace Drupal\custom_services;

use Drupal\Core\Session\AccountProxy;

/**
 * MyServices is a simple exampe of a Drupal 8 service.
 */
class MyServices {

  private $currentUser;
  /**
   * Part of the DependencyInjection magic happening here.
   */
  public function __construct(AccountProxy $currentUser) {
    $this->currentUser = $currentUser;
  }
  /**
   * Returns a a Drupal current user email as an owner.
   */
  public function whoIsYourOwner() {
    // return $this->currentUser->getDisplayName();
    return $this->currentUser->getEmail();
    //return array('#markup'=>$this->t('hello'));
  }
}
