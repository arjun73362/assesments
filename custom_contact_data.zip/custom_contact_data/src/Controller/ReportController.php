<?php
/**
 * @file
 * Contains \Drupal\custom_contact_data\Controller\ReportController
 */

namespace Drupal\custom_contact_data\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;

/**
 * Class Display.
 *
 * @package Drupal\custom_contact_data\Controller
 */
class ReportController extends ControllerBase {

  /**
   * showdata.
   *
   * @return string
   *   Return TabDisplayle format data.
   */
  public function report() {

// you can write your own query to fetch the data I have given my example.

    $result = \Drupal::database()->select('custom_contact_data', 'n')
            ->fields('n', array('id', 'name', 'mail', 'contact', 'city', 'description', 'gender'))
            ->execute()->fetchAllAssoc('id');
// Create the row element.
    $rows = array();
    foreach ($result as $row => $content) {
      $rows[] = array(
        'data' => array($content->id, $content->name, $content->mail, $content->contact, $content->city, $content->description, $content->gender));
    }
// Create the header.
    $header = array('id', 'name', 'mail', 'contact', 'city', 'description', 'gender');
    $output = array(
      '#theme' => 'table',    // Here you can write #type also instead of #theme.
      '#header' => $header,
      '#rows' => $rows
    );
    return $output;
  }
}
