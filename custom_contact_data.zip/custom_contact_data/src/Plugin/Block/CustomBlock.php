<?php
/**
 * @file
 * contains \Drupal\custom_contact_data\Plugin\Block\CustomBlock
 */
namespace Drupal\custom_contact_data\Plugin\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;
/**
 * provides custom_contact_block List Block
 * @Block(
 *   id="custom_contact_block",
 *   admin_label=@Translation("custom_contact_data Block"),
 * )
 */
class CustomBlock extends BlockBase{
    /**
     * {@inheritdoc}
     */
    public function build(){
        //return array('#markup'=>$this->t('my custom_contact_data'));
        return \Drupal::formBuilder()->getForm('Drupal\custom_contact_data\Form\CustomForm');
    }

}